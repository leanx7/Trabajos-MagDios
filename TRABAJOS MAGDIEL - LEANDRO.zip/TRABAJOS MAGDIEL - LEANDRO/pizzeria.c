#include<stdio.h>

int main(void) {

    
    int pizza;

    printf("1.- Pizza sensilla\n");
    printf("2.- Pizza mediana\n");
    printf("3.- Pizza familiar\n");
    printf("4.- Pizza jumbo\n");

    printf("Seleccione una opción: ");
    scanf("%d", &pizza);

    switch (pizza) {
        case 1:
            printf("Has seleccionado la pizza sensilla\n");
            break;
        case 2:
            printf("Has seleccionado la pizza mediana\n");
            break;
        case 3:
            printf("Has seleccionado la pizza familiar\n");
            break;
        case 4:
            printf("Has seleccionado la pizza jumbo\n");
            break;
        default:
            printf("Opción no válida\n");
    }

    printf("Gracias por su compra\n");

    return 0;
}
#include <stdio.h>

int main (void){

    int a, b, s, r, m;
    float d;

    printf("Introduce el valor de a:");
    scanf("%i", &a);
    printf("Introduce el valor de b:");
    scanf("%i", &b);

    s= a+b;
    r= a-b;
    m= a*b;
    d= a/b;

    printf("El resultado de la \n Suma: %i",s );
    printf("\n Resta: %i",r);
    printf("\n Multiplicacion: %i",m);
    printf("\n Division: %f", d);

    return 0;
}
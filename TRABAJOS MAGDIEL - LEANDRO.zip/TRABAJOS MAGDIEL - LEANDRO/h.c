#include <stdio.h>

int main(void) {
    int personas;
    float precioPlatillo, costoTotal;

    printf("\tLA LANGOSTA AHUMADA\n\n");

    printf("\tEl costo por platillo para hasta 200 personas es de $95.\n");
    printf("\tEl costo por platillo para mas de 200 y hasta 300 personas es de $85.\n");
    printf("\tEl costo por platillo para mas de 300 personas es de $75.\n\n");

    printf("Ingrese el numero de personas: ");
    scanf("%d", &personas);

    if (personas <= 0) {
        printf("\nNumero de personas no valido.\n");
    } 
    else {

        if (personas <= 200) {
            precioPlatillo = 95.0;
        } 
        else if (personas <= 300) {
            precioPlatillo = 85.0;
        } 
        else {
            precioPlatillo = 75.0;
        }
        costoTotal = personas * precioPlatillo;


        printf("\tEl costo por platillo sera de $%.2f\n", precioPlatillo);
        printf("\tEl costo total por el evento es de $%.2f\n", costoTotal);
    }

    return 0;
}
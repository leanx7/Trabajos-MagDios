#include <stdio.h>
int main(void){
    int autobus, personas;
    float kilometros, precio, costo_total, costo_por_persona;

    printf("\tSeleccione el tipo de autobus: \n");
    printf("\t[1]. Autobus A COSTO: $2.00/km\n");
    printf("\t[2]. Autobus B COSTO: $2.50/km\n");
    printf("\t[3]. Autobus C COSTO: $3.00/km\n");
    printf("Seleccione una opcion: ");
    scanf("%d", &autobus);

    printf("\tIngrese la cantidad de kilometros: \n");
    scanf("%f", &kilometros);

    printf("\tIngrese la cantidad de personas (NO PUEDE SER MAYOR A 20): \n\n");
    scanf("%d", &personas);



    switch (autobus) {
        case 1:
            precio = 2.0;
            break;
        case 2:
            precio = 2.5;
            break;
        case 3:
            precio = 3.0;
            break;

        default:
            printf("Opcion invalida.\n");
            break;
    }

    costo_total = kilometros * precio;
    costo_por_persona = costo_total / personas;

    printf("\t   =====TIKET DE VIAJE=====\n\n");

    printf("\tEl costo total del viaje es de $%.2f\n", costo_total);
    printf("\tEl costo por persona es de $%.2f\n", costo_por_persona);
    printf("\tEl costo por kilometro es de $%.2f\n", precio);
    printf("\tLas personas consideradas son: %d\n", personas);

    return 0;
}
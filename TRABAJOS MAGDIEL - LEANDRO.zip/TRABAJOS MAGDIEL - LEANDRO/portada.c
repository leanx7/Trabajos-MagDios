#include <stdio.h>

int main (void) {

    printf("\n Alumno: Ariel Guadalupe Ramirez Mendez"
        "\n Profesor: Magdiel Pascual García Juárez"
        "\n 1° Semestre"
        "\n UNIVERSIDAD DE LA SIERRA JUAREZ");

    return 0;
}
#include<stdio.h>

int main(void){

    int a, b;

    printf("%d", a !=b);
    printf("%d", a < b);
    printf("%d", a == b);
    printf("%d", a >= b);
    printf("%d", a <= b);

#include <stdio.h>

int main (void) {

    printf("\n1  2  3   4 5 ");
    printf("\n6           7 ");
    printf("\n8           9 ");
    printf("\n10          11 ");
    printf("\n12 13 14 15 16 ");

    return 0;
}
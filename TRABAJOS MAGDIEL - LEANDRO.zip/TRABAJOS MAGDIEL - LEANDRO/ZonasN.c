#include<stdio.h>

int main() {
    int a;
    
    printf("Ingresa un numero positivo: ");
    scanf("%d", &a);
    
    if (a < 0) {
        printf("El numero ingresado no es positivo.\n");
    } 
    else if (a <=20){
        printf("El numero esta en la zona 1: %d\n", a);
    }
    else if (a <= 40){
        printf("El numero esta en la zona 2: %d\n", a);
    }
    else if (a <= 60){
        printf("El numero esta en la zona 3: %d\n", a);
    }
}
#include<stdio.h>

int main(void){
    
    int n;

    printf("Introduce un numero:");
    scanf("%i", &n);

    if(n>10){
        printf("El numero introducido es:%i", n);
    }

    return 0;
}
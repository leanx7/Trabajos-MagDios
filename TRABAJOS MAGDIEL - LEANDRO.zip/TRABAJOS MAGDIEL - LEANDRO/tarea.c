#include <stdio.h>

int main(void) {

    int calificacion,tarea;
    printf("\t Ingresa tu Calificacion \n");
    scanf("%d", &calificacion);

    printf("\t Entregaste tu Tarea? (1 = Si, 0 = No) \n");
    scanf("%d", &tarea);

    if (calificacion >= 6 && tarea == 1) {
        printf("\t Felicidades, aprobaste la materia \n");
    } else {
        printf("\t No aprobaste la materia \n");
    }

    return 0;
}
#include <stdio.h>

int main (void) {

    char inicial;
    int edad;
    float prom;

    printf("Introduce tu inicial: ");
    scanf(" %c", &inicial);
    printf("Introduce tu edad: ");
    scanf("%i", &edad);
    printf("Introduce tu promedio: ");
    scanf("%f", &prom);
    printf("\nDATOS INGRESADOS\n");
    printf("Inicial: %c\n", inicial);
    printf("Edad: %i\n", edad);
    printf("Promedio: %f\n", prom);

    return 0;
}
#include <stdio.h>

int main(void) {
    char tipo;
    int tamaño;
    float precioInicial, precioFinal, kilos, total;

    printf("\tASOCIACION DE VINICULTORES\n\n");

    printf("\tAJUSTES AL PRECIO POR KILO DE UVA\n");
    printf("\t------------------------------------------\n");
    printf("\tTipo A, tamaño 1: +$0.02 por kilo\n");
    printf("\tTipo A, tamaño 2: +$0.30 por kilo\n");
    printf("\tTipo B, tamaño 1: -$0.30 por kilo\n");
    printf("\tTipo B, tamaño 2: -$0.50 por kilo\n");
    printf("\t------------------------------------------\n\n");

    printf("Ingrese el precio inicial por kilo: $");
    scanf("%f", &precioInicial);

    printf("Ingrese el tipo de uva (A o B): ");
    scanf(" %c", &tipo);

    printf("Ingrese el tamaño de la uva (1 o 2): ");
    scanf("%d", &tamaño);

    printf("Ingrese los kilos del embarque: ");
    scanf("%f", &kilos);

    switch (tipo) {
        case 'A':
        case 'a':
            if (tamaño == 1) {
                precioFinal = precioInicial + 0.02;
            } else {
                if (tamaño == 2) {
                    precioFinal = precioInicial + 0.30;
                } else {
                    printf("\nTamaño no valido.\n");
                    return 0;
                }
            }
            break;

        case 'B':
        case 'b':
            if (tamaño == 1) {
                precioFinal = precioInicial - 0.30;
            } else {
                if (tamaño == 2) {
                    precioFinal = precioInicial - 0.50;
                } else {
                    printf("\nTamaño no valido.\n");
                    return 0;
                }
            }
            break;

        default:
            printf("\nTipo de uva no valido.\n");
            return 0;
    }

    total = precioFinal * kilos;

    printf("\t  RESULTADOS \n\n");
    printf("\tTipo de uva: %c\n", tipo);
    printf("\tTamaño de uva: %d\n", tamaño);
    printf("\tPrecio inicial por kilo: $%.2f\n", precioInicial);
    printf("\tAjuste aplicado: $%.2f por kilo\n", precioFinal - precioInicial);
    printf("\tPrecio final por kilo: $%.2f\n", precioFinal);
    printf("\tKilos del embarque: %.2f\n", kilos);
    printf("\tTotal a recibir: $%.2f\n", total);

    return 0;
}
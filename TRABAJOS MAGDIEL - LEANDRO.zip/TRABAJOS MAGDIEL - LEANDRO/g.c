#include <stdio.h>
int main(void){

    int tamaño;
    float precio, precioFinal,kilos,total;
    char tipo;

    printf("\t BIENVENIDOS ALA SECCION DE COMPRA DE UVAS DE LOS AVICULTORES  \n\n");

    printf("\t          TIPOS Y TAMAÑOS DE UVAS             \n");
    printf("\t TIPO A, Tamaño 1: $60 pesos + $0.02 centavos \n");
    printf("\t TIPO A, Tamaño 2: $95 pesos + $0.30 centavos \n");
    printf("\t TIPO B, Tamaño 1: $65 pesos - $0.30 centavos \n");
    printf("\t TIPO B, Tamaño 2: $100 pesos - $0.50 centavos \n");

    printf("\t INGRESE EL TIPO DE UVA (A o B): \n");
    scanf(" %c", &tipo);

    printf("\t INGRESE EL TAMAÑO DE UVA (1 o 2): \n");
    scanf(" %d", &tamaño);

    printf("\t INGRESE LOS KILOS DE EMBARQUE: \n");
    scanf(" %f", &kilos);

    switch(tipo){
        case 'A':
        case 'a':
            if(tamaño == 1){
                precio = 60.00;
                precioFinal = precio + 0.02;
            }
            else if(tamaño == 2){
                precio = 95.00;
                precioFinal = precio + 0.30;
            }
            break;
        case 'B':
        case 'b':
            if(tamaño == 1){
                precio = 65.00;
                precioFinal = precio - 0.30;
            }
            else if(tamaño == 2){
                precio = 100.00;
                precioFinal = precio - 0.50;
            }
            break;
        default:
            printf("\t TIPO INVALIDO \n");
            return 1;
    }

    total = precioFinal * kilos;

    printf("\n\t========= GRACIAS POR SU COMPRA B) =========\n");

    printf("\tPrecio inicial por kilo: $%.2f\n", precio);
    printf("\tPrecio final por kilo: $%.2f\n", precioFinal);
    printf("\tKilos entregados: %.2f\n", kilos);
    printf("\tTotal a recibir: $%.2f\n", total);

    return 0;
}
#include <stdio.h>

/* Una persona abona el 15% de su salario semanal 
el 20% lo destina a pago de productos y servicios
el 50% a comidas 
y el 15% para diversion
Indique cuanto destino a cada rubro en 1 mes
*/

int main(void){

    float salario, sm, ahorro, PyS, comida, diversion;

    printf("Introduce tu salario semanal:");
    scanf("%f",& salario);

    sm = salario * 4;
    ahorro = sm * 0.15;
    PyS = sm * 0.20;
    comida = sm * 0.50;
    diversion = sm * 0.15;

    printf("\n El ahorro es de: %2f", ahorro);
    printf("\n El dinero para productos y servicios es de : %2f", PyS);
    printf("\n El dinero para comidas es de : %2f", comida);
    printf("\n El dinero para diversion es de : %2f", diversion);

    return 0;
}
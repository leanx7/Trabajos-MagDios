#include <stdio.h>

int main(void) {
    int personas;
    float precioPlatillo, costoTotal;       
    printf("\tLA LANGOSTA AHUMADA\n\n");

    printf("\tEl costo por platillo para hasta 200 personas es de $95.\n");
    printf("\tEl costo por platillo para mas de 200 y hasta 300 personas es de $85.\n");
    printf("\tEl costo por platillo para mas de 300 personas es de $75.\n\n");

    printf("Ingrese el numero de personas: ");
    scanf("%d", &personas);

    if (personas <= 0) {
        printf("\nNumero de personas no valido.\n");
    } 
    else if (personas <= 200) {
            printf("\t el costo por platillo sera de 95\n");
        }
    else if (personas <= 300) {
                printf("\t el costo por platillo sera de 85\n");
            } 
    else {
                printf("\t el costo por platillo sera de 75\n");
            }
        return 0;
    }